#!/bin/bash
sudo /home/pi/klipper_config/elements/scripts/change-hostname-as-root.sh $1
